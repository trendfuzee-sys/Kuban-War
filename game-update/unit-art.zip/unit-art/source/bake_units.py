"""Offline orthographic sprite baker for Kuban War (GLB + procedural meshes).
Requires numpy, scipy, trimesh, numba and Pillow. No runtime 3D dependencies.
"""
import io, json, math, struct, sys, zipfile
from pathlib import Path
import numpy as np
import trimesh
from scipy.spatial.transform import Rotation, Slerp
from PIL import Image, ImageFilter
from numba import njit

N=128
SAMPLES=2
PI=math.pi
# 4 idle, 8 locomotion, 8 attack, 4 death frames. No random animation state in simulation.
FRAMES=[('Idle',i/4) for i in range(4)]+[('Walk',i/8) for i in range(8)]+[('Attack',i/7) for i in range(8)]+[('Death',i/3) for i in range(4)]
COLS=6;ROWS=4
CAM=np.array([.81,.49,-1.0],dtype=np.float32); CAM/=np.linalg.norm(CAM)
RIGHT=np.cross([0,1,0],CAM).astype(np.float32);RIGHT/=np.linalg.norm(RIGHT)
UP=np.cross(CAM,RIGHT).astype(np.float32)
LIGHT=np.array([-.45,.85,-.65],np.float32);LIGHT/=np.linalg.norm(LIGHT)
HALF=LIGHT+CAM;HALF/=np.linalg.norm(HALF)

def img(raw):return np.array(Image.open(io.BytesIO(raw)).convert('RGB').resize((N,N),Image.Resampling.LANCZOS),np.uint8)
def rgb(col):
 col=col.lstrip('#'); col=''.join(c*2 for c in col) if len(col)==3 else col
 return np.array([int(col[i:i+2],16) for i in (0,2,4)],dtype=np.uint8)
def flat(color,rough=.75,metal=0,emit=0):
 a=np.zeros((N,N,3,3),np.uint8);a[:,:,0,:]=rgb(color);a[:,:,1,:]=[128,128,255];a[:,:,2,:]=[255,int(255*rough),int(255*metal)]
 return a,emit

def texture_from_archive(z,m):
 a=np.empty((N,N,3,3),np.uint8)
 for i,k in enumerate(['basecolor','normal','orm']): a[:,:,i,:]=img(z.read(m[k]))
 return a,0.

def material_stack(m):return np.ascontiguousarray(np.array([a for a,_ in m])),np.array([e for _,e in m],np.float32)

def norms(v,f):
 n=np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]]);a=np.zeros_like(v)
 for i in range(3):np.add.at(a,f[:,i],n)
 return a/np.maximum(np.linalg.norm(a,axis=1,keepdims=True),1e-8)

@njit(cache=True)
def raster(tris,norm,uv,mi,tex,emit,sz,light,half,cam):
 out=np.zeros((sz,sz,4),np.uint8);depth=np.full((sz,sz),-1e10,np.float32);T=tex.shape[1]
 for k in range(len(tris)):
  a,b,c=tris[k];x0,y0,z0=a;x1,y1,z1=b;x2,y2,z2=c
  den=(y1-y2)*(x0-x2)+(x2-x1)*(y0-y2)
  if abs(den)<1e-6:continue
  # Two-sided render; depth handles back faces, allows cloth sails.
  lx=max(0,int(math.floor(min(x0,x1,x2))));rx=min(sz-1,int(math.ceil(max(x0,x1,x2))))
  ly=max(0,int(math.floor(min(y0,y1,y2))));ry=min(sz-1,int(math.ceil(max(y0,y1,y2))))
  mat=mi[k]
  for y in range(ly,ry+1):
   py=y+.5
   for x in range(lx,rx+1):
    px=x+.5
    w0=((y1-y2)*(px-x2)+(x2-x1)*(py-y2))/den
    w1=((y2-y0)*(px-x2)+(x0-x2)*(py-y2))/den;w2=1-w0-w1
    if min(w0,w1,w2)<-1e-5:continue
    z=w0*z0+w1*z1+w2*z2
    if z<=depth[y,x]:continue
    u=w0*uv[k,0,0]+w1*uv[k,1,0]+w2*uv[k,2,0];v=w0*uv[k,0,1]+w1*uv[k,1,1]+w2*uv[k,2,1]
    tx=int((u-math.floor(u))*T)%T;ty=min(T-1,max(0,int(v*(T-1))))
    nx=w0*norm[k,0,0]+w1*norm[k,1,0]+w2*norm[k,2,0];ny=w0*norm[k,0,1]+w1*norm[k,1,1]+w2*norm[k,2,1];nz=w0*norm[k,0,2]+w1*norm[k,1,2]+w2*norm[k,2,2]
    ln=max(1e-6,math.sqrt(nx*nx+ny*ny+nz*nz));nx/=ln;ny/=ln;nz/=ln
    if nx*cam[0]+ny*cam[1]+nz*cam[2]<0:nx=-nx;ny=-ny;nz=-nz
    # Bake normal-map relief and roughness/metallic response into the lighting.
    bx=(float(tex[mat,ty,tx,1,0])-128.)/127.;by=(float(tex[mat,ty,tx,1,1])-128.)/127.
    nd=max(0.,min(1.,nx*light[0]+ny*light[1]+nz*light[2]+.16*bx+.12*by))
    rough=float(tex[mat,ty,tx,2,1])/255.;metal=float(tex[mat,ty,tx,2,2])/255.
    spec=max(0.,nx*half[0]+ny*half[1]+nz*half[2])**(5.+40.*(1.-rough))*(.08+.22*metal)
    ao=float(tex[mat,ty,tx,2,0])/255.
    fac=(.52+.66*nd)*(.72+.28*ao);em=emit[mat]
    for ch in range(3):
     base=float(tex[mat,ty,tx,0,ch]);val=base*(fac+em*.45)+spec*255.;out[y,x,ch]=int(min(255.,max(0.,val)))
    out[y,x,3]=255;depth[y,x]=z
 return out

# Meshes share primitive topology; only one small raster per frame is stored.
SP=trimesh.creation.icosphere(subdivisions=1)
SP_HI=trimesh.creation.icosphere(subdivisions=2)
BOX=trimesh.creation.box(extents=[2,2,2]);CYL=trimesh.creation.cylinder(radius=1,height=2,sections=12);CONE=trimesh.creation.cone(radius=1,height=2,sections=12);CONE.apply_translation([0,0,-1])
for m in [CYL,CONE]:m.apply_transform(trimesh.transformations.rotation_matrix(-PI/2,[1,0,0]))

class Model:
 def __init__(self,mats):self.mats=mats;self.parts=[];self.piv={};self.groups={};self.kind='human';self.glow=False;self.weapon='none'
 def add(self,mesh,pos,scale,mat,group='body',rot=None,smooth=True):
  v=np.asarray(mesh.vertices,dtype=np.float32).copy();f=np.asarray(mesh.faces,dtype=np.int32)
  # UV on primitive; expand seam-crossing faces rather than stretch textures.
  uv=np.column_stack([.5+np.arctan2(v[:,0],-v[:,2])/(2*PI),np.clip((v[:,1].max()-v[:,1])/max(.001,np.ptp(v[:,1])),0,1)])[f].astype(np.float32)
  cross=np.ptp(uv[:,:,0],axis=1)>.5;uv[cross,:,0]=np.where(uv[cross,:,0]<.5,uv[cross,:,0]+1,uv[cross,:,0])
  v*=np.array(scale,np.float32)
  if rot is not None:v=v@rot.T
  v+=np.array(pos,np.float32)
  n=norms(v,f)[f] if smooth else np.repeat(norms(v[f].reshape(-1,3),np.arange(f.size).reshape(-1,3)).reshape(-1,3,3)[:,0:1],3,1)
  self.parts.append((v[f],n.astype(np.float32),uv,self.mats[mat],group))
 def ell(self,p,s,m,g='body',hi=False):self.add(SP_HI if hi else SP,p,s,m,g)
 def box(self,p,s,m,g='body',rot=None):self.add(BOX,p,np.array(s)/2,m,g,rot,False)
 def rod(self,a,b,r,m,g='body',r2=None):
  a,b=np.array(a),np.array(b);d=b-a;ln=np.linalg.norm(d)
  if ln<1e-6:return
  rot=trimesh.geometry.align_vectors([0,1,0],d/ln)[:3,:3];self.add(CYL,(a+b)/2,(r,ln/2,r if r2 is None else r2),m,g,rot)
 def cone(self,p,s,m,g='body',rot=None):self.add(CONE,p,s,m,g,rot)
 def tri(self,v,f,m,g='body'):
  v=np.asarray(v,np.float32);f=np.asarray(f,np.int32);uv=np.zeros((len(f),3,2),np.float32)
  uv[:,:,0]=(v[f,0]-v[:,0].min())/max(.001,np.ptp(v[:,0]));uv[:,:,1]=(v[:,1].max()-v[f,1])/max(.001,np.ptp(v[:,1]));n=norms(v,f)[f];self.parts.append((v[f],n,uv,self.mats[m],g))
 def pose(self,clip,p):
  phase=p*2*PI;walk=math.sin(phase);swing=math.sin(p*PI);swing2=math.sin(p*PI*2)
  angles={};shift=np.zeros(3,np.float32);ka=0
  if self.kind=='vehicle':shift[1]=.035*math.sin(phase) if clip!='Attack' else .03*swing
  elif clip=='Walk':
   angles={'legL':.54*walk,'legR':-.54*walk,'armL':-.43*walk,'armR':.43*walk,'foreL':.6*walk,'foreR':-.6*walk,'hindL':-.6*walk,'hindR':.6*walk,'tail':.18*walk};shift[1]=.035*abs(walk)
   if self.kind=='mounted':angles.update(legL=.045*walk,legR=-.045*walk,armL=-.13*walk,armR=.13*walk);shift[1]=.055*abs(walk)
  elif clip=='Attack':
   angles={'armR':(-1.5*math.sin(p*PI/0.55) if p<.55 else 1.05*math.sin((p-.55)*PI/.45)), 'armL':.4*swing,'head':-.22*swing,'foreL':-.28*swing,'foreR':-.28*swing};shift[2]=-.12*swing;shift[1]=-.025*swing
   if self.weapon in ('staff','book','bow'):angles['armR']=.75*swing;angles['armL']=.18*swing;shift[2]=-.025*swing
   if self.kind=='mounted':angles['foreL']*=.5;angles['foreR']*=.5
  else:angles={'armL':.025*math.cos(phase),'armR':-.025*math.cos(phase),'tail':.10*math.cos(phase)};shift[1]=.014*(1+math.cos(phase))
  vs=[];ns=[];uv=[];ms=[]
  for v,n,u,m,g in self.parts:
   a=angles.get(g,0.);piv=self.piv.get(g,np.zeros(3,np.float32));rr=Rotation.from_rotvec(np.array([a,0,0])).as_matrix().astype(np.float32)
   vv=(v-piv)@rr.T+piv+shift;nn=n@rr.T
   vs.append(vv);ns.append(nn);uv.append(u);ms.append(np.full(len(v),m,np.int32))
  v=np.concatenate(vs);n=np.concatenate(ns)
  if clip=='Death':v,n=fall(v,n,p)
  return v,n,np.concatenate(uv),np.concatenate(ms)

def fall(v,n,p):
 # Fall to the ground over 0.4 s, then remain a corpse; no game-state changes.
 rr=Rotation.from_rotvec(np.array([0,0,-1.47*p])).as_matrix().astype(np.float32);v=v@rr.T;n=n@rr.T;v[:,:,1]-=min(0.,float(v[:,:,1].min()));return v,n

def human(m,rec,origin=(0,0,0),mounted=False):
 id=rec['id'];race=id.split('/')[0];hat=rec['hat'];w=rec['weapon'];boss=id.startswith('boss/');golem=rec['kind']=='golem';undead=rec['kind']=='undead';legend=id.endswith('/legend');spy=id.endswith('/spy');worker=id.endswith('/worker');heavy=(race=='mon' and id.endswith(('unit_2','unit_3','legend'))) or (race=='nov' and id.endswith('unit_2')) or boss
 if rec.get('undead_role')==2:heavy=True
 if boss:
  role=int(id.rsplit('_',1)[1]);hat=['papakha','hood','beanie','cap','none','fur','hair','none','pirate'][role];w=['sabre','club','bottle','club','club','staff','staff','club','sabre'][role];heavy=role in (1,3,4,7,8);undead=role==8
 m.weapon=w
 o=np.array(origin,np.float32);base_width=(1.58 if boss and role in (2,4,7) else 1.25) if boss else 1.16 if heavy else 1.0
 def p(a):return o+np.array(a)*[base_width,1,1]
 def e(a,s,mat,g='body',hi=False):m.ell(p(a),np.array(s)*[base_width,1,1],mat,g,hi)
 def b(a,s,mat,g='body',rot=None):m.box(p(a),np.array(s)*[base_width,1,1],mat,g,rot)
 def rod(a,b,r,mat,g='body'):m.rod(p(a),p(b),r,mat,g)
 for side,g in [(-1,'legL'),(1,'legR')]:
  x=.16*side
  m.piv[g]=p((x,.75,0))
  if mounted:
   rod((x,.71,0),(side*.37,.47,-.02),.12,'pants',g);rod((side*.37,.47,-.02),(side*.39,.12,-.06),.10,'leather',g);e((side*.39,.12,-.12),(.12,.10,.17),'leather',g)
  else:
   rod((x,.76,0),(x,.42,0),.125,'pants',g);rod((x,.43,0),(x,.14,-.01),.104,'leather',g);e((x,.1,-.085),(.125,.1,.18),'leather',g)
   if heavy:e((x,.40,-.095),(.105,.10,.065),'metal',g)
  if race=='nov' and not boss:rod((x+.08*side,.73,-.025),(x+.08*side,.43,-.025),.018,'trim',g)
 e((0,.94,0),(.295,.36,.19),'coat',hi=True)
 e((0,.70,.01),(.30,.23,.20),'coat')
 b((0,.77,0),(.53,.095,.38),'leather');b((0,.77,-.205),(.12,.09,.04),'gold')
 for z in [.89,1.00,1.11]:e((0,z,-.19),(.026,.026,.02),'gold')
 if race=='kaz' or legend or boss:
  for x in [-.12,.12]:rod((x,.82,-.19),(x,1.19,-.17),.018,'gold')
 if race=='bog' or spy or worker:
  b((0,.96,.20),(.29,.38,.20),'leather');rod((-.18,1.21,-.13),(.15,.80,-.18),.025,'leather')
 if heavy or golem:
  for y in [.87,.97,1.07,1.17]:
   for x in [-.18,-.06,.06,.18]:b((x,y,-.185),(.108,.083,.045),'metal')
  for x in [-.29,.29]:e((x,1.19,-.01),(.19,.13,.19),'metal')
 if golem:
  e((0,1.0,-.17),(.17,.17,.07),'glow');e((0,.70,.02),(.31,.18,.22),'metal')
 if id=='boss/relic_5' or id=='boss/relic_8' or legend:
  b((0,.86,.19),(.57,.75,.095),'coat');e((0,1.20,.06),(.38,.09,.22),'trim')
 for side,g in [(-1,'armL'),(1,'armR')]:
  x=side*.34;m.piv[g]=p((x,1.18,0))
  e((x,1.12,0),(.13,.14,.13),'coat',g);rod((x,1.1,0),(x,.91,-.02),.10,'coat',g);rod((x,.91,-.02),(x,.76,-.13),.082,'metal' if heavy else 'coat',g);e((x,.75,-.15),(.087,.084,.085),'skin' if not golem else 'metal',g)
  if heavy:b((x,.85,-.12),(.14,.15,.07),'metal',g)
 e((0,1.28,0),(.10,.10,.10),'skin');e((0,1.43,0),(.15,.18,.135),'skin',hi=True);e((0,1.42,-.133),(.037,.045,.045),'skin')
 for x in [-.058,.058]:
  e((x,1.47,-.115),(.026,.015,.022),'glow' if undead or golem else 'eye');e((x,1.47,-.132),(.010,.012,.009),'glow' if undead else 'dark')
  if not undead:rod((x-.025,1.49,-.127),(x+.026,1.49,-.127),.008,'dark')
 if undead:
  b((0,1.365,-.125),(.14,.034,.02),'dark')
  for x in [-.05,-.025,0,.025,.05]:b((x,1.37,-.14),(.015,.025,.014),'eye')
 elif race=='kaz' and not worker:rod((-.067,1.389,-.131),(.067,1.389,-.131),.014,'dark')
 if id=='bog/unit_1':
  for x in [-.056,.056]:b((x,1.47,-.142),(.065,.037,.009),'dark');e((x,1.47,-.15),(.022,.012,.007),'eye')
 if hat=='straw':e((0,1.55,0),(.245,.035,.23),'straw');m.cone(p((0,1.62,0)),(.14,.10,.14),'straw')
 elif hat=='papakha':e((0,1.59,0),(.185,.16,.17),'fur');e((0,1.70,0),(.11,.035,.10),'trim')
 elif hat=='cap':e((0,1.55,0),(.16,.085,.15),'dark');b((0,1.52,-.145),(.21,.025,.18),'dark')
 elif hat=='beanie':e((0,1.58,0),(.164,.12,.15),'trim');e((0,1.53,0),(.172,.04,.16),'dark')
 elif hat=='fur':e((0,1.58,0),(.18,.085,.16),'fur');e((0,1.61,0),(.13,.09,.13),'coat')
 elif hat=='helm':
  e((0,1.55,0),(.18,.058,.17),'metal');m.cone(p((0,1.66,0)),(.16,.115,.145),'metal');e((0,1.78,0),(.037,.068,.035),'trim');e((0,1.39,.10),(.16,.14,.08),'metal')
 elif hat=='pirate':e((0,1.57,0),(.25,.05,.22),'dark');e((0,1.64,.015),(.16,.095,.15),'coat');b((0,1.60,-.14),(.21,.03,.025),'gold')
 elif hat=='hood':e((0,1.48,.065),(.175,.20,.14),'coat');e((0,1.61,0),(.16,.075,.16),'coat')
 else:e((0,1.54,.02),(.15,.10,.13),'dark')
 if boss and id.endswith('relic_8'):
  e((0,1.6,0),(.25,.05,.19),'dark');e((0,1.65,0),(.17,.095,.13),'coat');b((0,1.62,-.13),(.22,.04,.035),'gold')
 # Individual props make the nine optional bosses distinguishable at tactical zoom.
 if boss:
  if role==0:
   e((0,1.22,.04),(.37,.105,.23),'fur');b((0,.93,.205),(.65,.67,.085),'coat');e((0,1.70,0),(.09,.04,.08),'gold')
  elif role==1:
   b((-.39,.76,-.21),(.23,.25,.20),'metal','armL');e((-.39,.76,-.33),(.075,.08,.04),'glow','armL');b((0,1.36,-.10),(.19,.035,.03),'dark')
  elif role==2:
   e((0,.87,-.015),(.34,.32,.25),'coat');b((-.39,.74,-.18),(.25,.33,.23),'wood','armL');b((-.39,.87,-.18),(.27,.055,.25),'metal','armL')
  elif role==3:
   b((-.39,.99,-.22),(.27,.46,.075),'metal','armL');b((-.39,1.05,-.27),(.17,.18,.025),'dark','armL');e((0,1.58,-.12),(.055,.027,.02),'gold')
  elif role==4:
   b((0,1.44,.015),(.30,.34,.23),'metal');e((0,1.47,-.145),(.10,.027,.035),'glow');b((0,.95,-.14),(.35,.38,.12),'metal');e((0,1.00,-.23),(.10,.12,.06),'glow')
   for x,g in [(-.34,'armL'),(.34,'armR')]:b((x,.87,-.03),(.24,.38,.24),'metal',g)
  elif role==5:
   e((0,1.20,.04),(.39,.12,.25),'fur');e((0,1.36,-.055),(.12,.17,.105),'fur');b((-.33,.74,-.17),(.13,.21,.15),'wood','armL')
  elif role==6:
   for x in [-.058,.058]:e((x,1.47,-.145),(.041,.032,.016),'glow')
   rod((-.36,.72,-.18),(-.36,1.0,-.18),.06,'green','armL');b((0,.95,.20),(.29,.40,.22),'metal')
  elif role==7:
   b((0,1.46,0),(.32,.33,.28),'metal');e((0,1.47,-.16),(.105,.034,.035),'glow');b((-.32,1.19,.01),(.40,.23,.35),'metal');b((.32,1.19,.01),(.30,.19,.28),'metal')
   for x,g in [(-.34,'armL'),(.34,'armR')]:b((x,.79,-.08),(.30,.27,.25),'metal',g)
  elif role==8:
   for x in [-.12,.12]:e((x,1.37,.04),(.075,.22,.07),'fur')
   e((0,1.61,0),(.27,.05,.22),'dark');e((0,1.65,0),(.16,.10,.15),'coat');m.glow=True
 # Weapon geometry belongs to the right arm, not a floating icon.
 hand=(.34,.75,-.17);g='armR'
 if w=='sabre':
  rod((.34,.68,-.17),(.34,.88,-.17),.03,'leather',g);rod((.24,.86,-.17),(.44,.86,-.17),.022,'gold',g)
  for a,bb in zip([( .34,.86,-.17),(.40,1.07,-.19),(.48,1.27,-.23)],[(.40,1.07,-.19),(.48,1.27,-.23),(.57,1.43,-.28)]):rod(a,bb,.032,'metal',g)
 elif w=='club':
  rod((.34,.60,-.18),(.37,1.40,-.23),.046,'leather',g);rod((.37,1.12,-.23),(.39,1.45,-.23),.084,'metal' if heavy else 'wood',g)
  if boss:
   for x in [-.1,.1]:rod((.38,1.3,-.23),(.38+x,1.3,-.25),.025,'metal',g)
 elif w=='pick':rod((.34,.65,-.18),(.34,1.42,-.18),.027,'wood',g);rod((.17,1.42,-.18),(.51,1.42,-.18),.038,'metal',g)
 elif w=='bottle':rod((.34,.74,-.18),(.34,1.12,-.18),.064,'green',g);rod((.34,1.1,-.18),(.34,1.26,-.18),.035,'green',g)
 elif w=='staff':rod((.34,.13,-.19),(.34,1.79,-.19),.032,'wood',g);e((.34,1.80,-.19),(.09,.10,.09),'glow' if race=='bog' or boss else 'gold',g)
 elif w=='bow':
  pts=[(.34,.43,-.20),(.47,.58,-.26),(.51,.78,-.31),(.47,1.02,-.26),(.34,1.18,-.20)]
  for a,bb in zip(pts,pts[1:]):rod(a,bb,.027,'wood',g)
  rod(pts[0],pts[-1],.008,'eye',g);rod((.34,.79,-.15),(.34,.79,-.57),.013,'metal',g);b((-.25,1.07,.20),(.12,.46,.12),'leather');
 elif w in ('book','brief'):
  b((.37,.68,-.20),(.26,.26,.12),'leather',g);b((.37,.68,-.27),(.22,.20,.025),'eye' if w=='book' else 'coat',g);b((.37,.68,-.29),(.046,.17,.015),'gold',g)
 if race=='mon' and id.endswith('unit_4'):
  rod((.34,.20,-.26),(.34,1.94,-.26),.035,'wood',g);m.cone(p((.34,2.0,-.26)),(.063,.13,.063),'metal',g)
 if id=='mon/unit_3' or id=='mon/legend' or golem:e((-.36,.92,-.26),(.23,.27,.055),'metal','armL');e((-.36,.92,-.31),(.08,.08,.026),'gold','armL')

def animal(m,kind,horse=False):
 m.kind='animal' if not horse else 'mounted';fur='horse_fur' if horse else 'fur';h=.88 if horse else .65;length=.73 if horse else .53;width=.28 if horse else .28
 if kind=='bear':h=.83;length=.70;width=.42
 if kind=='hare':h=.38;length=.38;width=.21
 if kind=='deer':h=.92;length=.55;width=.22
 if kind=='boar':h=.60;length=.63;width=.34
 if kind=='fox':h=.52;length=.49;width=.22
 m.ell((0,h,0),(width,.31 if horse or kind=='bear' else h*.37,length),fur,hi=True)
 m.ell((0,h+.04,-length*.63),(width*.85,.29,length*.44),fur)
 neck_top=(0,h+( .47 if horse or kind=='deer' else .16),-length*.83)
 m.rod((0,h,-length*.58),neck_top,width*.70,fur)
 head=(0,neck_top[1]+.045,neck_top[2]-.16);m.ell(head,(width*.62,.18 if horse else .15,.26 if horse or kind=='wolf' or kind=='boar' else .19),fur,hi=True)
 snout=(0,head[1]-.065,head[2]-.16);m.ell(snout,(width*.47,.11,.14),fur);m.ell((0,snout[1],snout[2]-.12),(.075,.055,.05),'dark')
 for side in [-1,1]:
  x=side*width*.5;m.ell((x,head[1]+.047,head[2]-.08),(.025,.025,.028),'glow' if kind=='bear' else 'dark')
  ear=(side*width*.55,head[1]+.15,head[2]+.03)
  if kind=='hare':m.ell((ear[0],ear[1]+.15,ear[2]),(.047,.20,.05),fur)
  elif kind=='bear' or kind=='boar':m.ell(ear,(.075,.075,.07),fur)
  else:m.cone((ear[0],ear[1]+.08,ear[2]),(.075,.12,.08),fur)
  if kind=='boar':m.rod((side*.10,snout[1]-.08,snout[2]),(side*.21,snout[1]+.07,snout[2]-.12),.03,'claws')
  if kind=='deer':
   a=(side*.12,head[1]+.16,head[2]+.04);b=(side*.21,head[1]+.53,head[2]+.15);m.rod(a,b,.025,'claws');m.rod((side*.16,head[1]+.33,head[2]+.11),(side*.30,head[1]+.45,head[2]-.04),.018,'claws')
  for pos,g in [(-length*.57,'fore'),(length*.61,'hind')]:
   grp=g+('L' if side<0 else 'R');p=(side*width*.70,h-.12,pos);m.piv[grp]=np.array(p,np.float32)
   m.rod(p,(p[0],h*.45,pos+.035),width*.32,fur,grp);m.rod((p[0],h*.45,pos+.035),(p[0],.10,pos-.025),width*.24,fur,grp);m.ell((p[0],.075,pos-.07),(width*.30,.075,.12),'claws' if not horse else 'leather',grp)
  if kind=='bear':m.ell((side*.28,.83,-.25),(.19,.25,.24),fur)
 tail=(0,h+.04,length*.87);m.piv['tail']=np.array(tail,np.float32)
 if horse:m.rod(tail,(0,.38,length+ .31),.075,'dark','tail')
 elif kind in ('wolf','fox'):m.ell((0,h*.85,length+.22),(.12,.15,.29),fur,'tail');m.ell((0,h*.72,length+.39),(.09,.11,.16),'trim' if kind=='fox' else fur,'tail')
 else:m.ell((0,h+.04,length+.08),(.085,.085,.10),fur,'tail')
 if horse:
  m.ell((0,h+.29,.04),(width+.035,.08,.36),'coat');m.box((0,h+.35,.04),(.43,.11,.36),'leather')
  for side in [-1,1]:m.rod((side*.08,head[1],head[2]-.09),(side*.17,h+.40,-.12),.015,'leather')
 return h+.30

def vessel(m,kind):
 m.kind='vehicle';flag=kind=='flagship';wagon=kind=='wagon'
 if wagon:
  m.box((0,.35,0),(.88,.24,1.50),'wood');m.box((0,.57,.17),(.79,.40,1.03),'wood');m.box((0,.79,.17),(.85,.08,1.08),'coat')
  for side in [-1,1]:
   for z in [-.47,.53]:m.rod((side*.43,.30,z),(side*.52,.30,z),.30,'wood');m.rod((side*.51,.30,z),(side*.55,.30,z),.31,'metal');m.rod((side*.55,.30,z),(side*.60,.30,z),.065,'gold')
  for x in [-.25,.25]:m.rod((x,.29,-.68),(x,.28,-1.35),.035,'wood')
  return
 # faceted hull, tapered prow, deck rails, masts, folded sail surfaces
 W=.68 if flag else .52;L=1.65 if flag else 1.30
 v=[(-W,.28,-L*.58),(0,.35,-L),(W,.28,-L*.58),(W,.28,L*.68),(0,.30,L*.88),(-W,.28,L*.68),(-W*.60,.03,-L*.50),(0,.04,-L*.82),(W*.60,.03,-L*.50),(W*.60,.03,L*.56),(0,.04,L*.71),(-W*.60,.03,L*.56)]
 f=[]
 for i in range(6):j=(i+1)%6;f.extend([(i,j,j+6),(i,j+6,i+6)])
 for i in range(1,5):f.append((0,i,i+1))
 m.tri(v,f,'wood');m.box((0,.29,0),(W*1.6,.06,L*1.28),'coat')
 for side in [-1,1]:
  m.rod((side*W,.37,-L*.56),(side*W,.37,L*.67),.038,'gold')
  for z in np.linspace(-L*.43,L*.56,5 if flag else 3):m.rod((side*W*.68,.40,z),(side*W*1.1,.42,z),.07,'metal')
 for z,height,sw in [(-.55,1.6,.64),(.32,1.92,.76)]+([(.95,1.4,.51)] if flag else []):
  m.rod((0,.34,z),(0,height+.18,z),.042,'wood');m.rod((-sw,height,z),(sw,height,z),.029,'wood')
  # curved sail, triangulated strip, with a bright insignia below yard
  vv=[]
  for y in [height,height-.25,height-.57,height-.86]:
   for x in np.linspace(-sw,sw,7):vv.append((x,y,z-.22*(1-(x/sw)**2)*math.sin((height-y)/.86*PI)))
  ff=[]
  for a in range(3):
   for b in range(6):q=a*7+b;ff.extend([(q,q+1,q+7),(q+1,q+8,q+7)])
  m.tri(vv,ff,'sail');m.rod((-sw,height-.86,z),(sw,height-.86,z),.023,'wood');m.rod((0,height+.12,z),(0,height+.37,z),.018,'wood');m.tri([(0,height+.35,z),(.32,height+.29,z), (0,height+.17,z)],[(0,1,2)],'trim')
 m.box((0,.56,L*.49),(W*1.16,.43,L*.44),'coat');m.box((0,.81,L*.49),(W*1.23,.09,L*.48),'gold')
 for x in [-W*.34,0,W*.34]:m.box((x,.62,L*.73),(.11,.14,.035),'glow')
 m.glow=flag

def procedural(z,rec):
 materials=[];ids={}
 def add(n,x):ids[n]=len(materials);materials.append(x)
 for m in rec['materials']:add(m['name'],texture_from_archive(z,m))
 for n,c,r,me,em in [('trim','a54436',.85,0,0),('gold','c89c46',.45,.65,0),('eye','ece5cd',.75,0,0),('dark','282a29',.85,0,0),('straw','d5b862',.92,0,0),('green','438b64',.32,.1,0),('glow','64e9dc',.36,0,1)]:
  if n not in ids:add(n,flat(c,r,me,em))
 for n,c in [('coat',rec['coat']),('pants',rec['pants']),('skin','b6a48b'),('leather','49372b'),('metal','a4a9a9'),('fur','5b4639'),('horse_fur','845639'),('claws','aeb6aa'),('wood','785334')]:
  if n not in ids:add(n,flat(c))
 if rec['kind']=='vehicle':
  # Tint the actual coat texture for sails while preserving its textile grain.
  tex=materials[ids['coat']][0].copy();t=tex[:,:,0,:].mean(-1,keepdims=True).astype(np.float32);t/=max(t.mean(),1);col=rgb('5bc9c9' if rec['id'].endswith('flagship') else 'd4c8a9');tex[:,:,0,:]=np.clip(t*col,0,255);add('sail',(tex,.45 if rec['id'].endswith('flagship') else 0))
 if rec['kind']=='undead':
  tex=materials[ids['skin']][0].copy();t=tex[:,:,0,:].astype(np.float32);t/=max(t.mean(),1);tex[:,:,0,:]=np.clip(t*rgb(rec.get('skin_tint','a0b7a3')),0,255);materials[ids['skin']]=(tex,0)
 m=Model(ids);m.kind=rec['kind']
 if rec['kind']=='animal':animal(m,rec['id'].split('/')[-1])
 elif rec['kind']=='vehicle':vessel(m,rec['id'].split('/')[-1])
 elif rec['kind']=='mounted':h=animal(m,'horse',True);human(m,rec,(0,h-.23,.06),True)
 else:human(m,rec)
 m.glow=m.glow or rec['kind']=='undead';return m,material_stack(materials)

class GLBModel:
 def __init__(self,raw):
  n=struct.unpack_from('<I',raw,12)[0];self.j=json.loads(raw[20:20+n]);self.buf=raw[28+n:];j=self.j;self.parts=[];self.kind='human';self.glow=False
  self.mats=[]
  for m in j['materials']:
   p=m.get('pbrMetallicRoughness',{});a=np.empty((N,N,3,3),np.uint8);a[:,:,0,:]=np.uint8(np.array(p.get('baseColorFactor',[1,1,1,1])[:3])*255);a[:,:,1,:]=[128,128,255];a[:,:,2,:]=[255,255,0]
   for ix,obj in enumerate([p.get('baseColorTexture'),m.get('normalTexture'),p.get('metallicRoughnessTexture')]):
    if obj is None:continue
    im=j['images'][j['textures'][obj['index']]['source']];a[:,:,ix,:]=img(self.view(im['bufferView']))
   self.mats.append((a,max(m.get('emissiveFactor',[0]))))
  self.maps=material_stack(self.mats);self.parents={k:i for i,node in enumerate(j['nodes']) for k in node.get('children',[])};self.clips={x['name']:x for x in j.get('animations',[])}
  for i,node in enumerate(j['nodes']):
   if 'mesh' not in node:continue
   for p in j['meshes'][node['mesh']]['primitives']:
    at=p['attributes'];v=self.acc(at['POSITION']);f=self.acc(p['indices']).reshape(-1,3).astype(np.int32);u=self.acc(at['TEXCOORD_0']) if 'TEXCOORD_0' in at else np.zeros((len(v),2));n=self.acc(at['NORMAL']) if 'NORMAL' in at else norms(v,f)
    uv=u[f].copy();cross=np.ptp(uv[:,:,0],axis=1)>.5;uv[cross,:,0]=np.where(uv[cross,:,0]<.5,uv[cross,:,0]+1,uv[cross,:,0]);self.parts.append((i,v[f],n[f],uv,np.full(len(f),p.get('material',0),np.int32)))
 def view(self,i):w=self.j['bufferViews'][i];o=w.get('byteOffset',0);return self.buf[o:o+w['byteLength']]
 def acc(self,i):
  a=self.j['accessors'][i];w=self.j['bufferViews'][a['bufferView']];dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']]);cols={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];return np.ndarray((a['count'],cols),dt,buffer=self.buf,offset=w.get('byteOffset',0)+a.get('byteOffset',0),strides=(w.get('byteStride',cols*dt.itemsize),dt.itemsize)).copy()
 def pose(self,clip,p):
  j=self.j;rs={};an=self.clips.get('Idle' if clip=='Death' else clip)
  if an:
   for ch in an['channels']:
    if ch['target']['path']!='rotation':continue
    sp=an['samplers'][ch['sampler']];tt=self.acc(sp['input']).ravel();rr=self.acc(sp['output']);rs[ch['target']['node']]=Slerp(tt,Rotation.from_quat(rr))([tt[0]+(tt[-1]-tt[0])*p]).as_matrix()[0]
  mats={}
  def get(i):
   if i in mats:return mats[i]
   node=j['nodes'][i];a=np.eye(4)
   if 'matrix' in node:a=np.array(node['matrix']).reshape(4,4).T
   else:a[:3,:3]=rs.get(i,Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix())*np.array(node.get('scale',[1,1,1]))[None,:];a[:3,3]=node.get('translation',[0,0,0])
   if i in self.parents:a=get(self.parents[i])@a
   mats[i]=a;return a
  vs=[];ns=[];us=[];ms=[]
  for i,v,n,u,m in self.parts:
   a=get(i);vs.append(v@a[:3,:3].T+a[:3,3]);ns.append(n@np.linalg.inv(a[:3,:3]));us.append(u);ms.append(m)
  v=np.concatenate(vs);n=np.concatenate(ns);v[:,:,1]+=.025*abs(math.sin(p*2*PI)) if clip=='Walk' else .012*math.cos(p*2*PI) if clip=='Idle' else 0
  if clip=='Death':v,n=fall(v,n,p)
  return v,n,np.concatenate(us),np.concatenate(ms)

def bake(m,maps,size,worldheight,out):
 poses=[m.pose(clip,p) for clip,p in FRAMES];pv=np.concatenate([q[0].reshape(-1,3) for q in poses]);sx=pv@RIGHT;sy=pv@UP;lo=np.array([sx.min(),sy.min()]);hi=np.array([sx.max(),sy.max()]);span=hi-lo
 # Anchor is the projection of world origin, not the bottom of the rectangular atlas.
 scale=(size-10)/max(span);center=(lo+hi)/2;ax=size/2-center[0]*scale;ay=size/2+center[1]*scale
 atlas=Image.new('RGBA',(size*COLS,size*ROWS));S=size*SAMPLES
 for i,(v,n,u,mi) in enumerate(poses):
  projected=np.empty_like(v,dtype=np.float32);projected[:,:,0]=(v@RIGHT*scale+ax)*SAMPLES;projected[:,:,1]=(-v@UP*scale+ay)*SAMPLES;projected[:,:,2]=v@CAM
  pixels=raster(projected,np.ascontiguousarray(n,np.float32),np.ascontiguousarray(u,np.float32),np.ascontiguousarray(mi,np.int32),*maps,S,LIGHT,HALF,CAM)
  im=Image.fromarray(pixels,'RGBA').resize((size,size),Image.Resampling.LANCZOS)
  if m.glow:
   mask=im.getchannel('A').filter(ImageFilter.GaussianBlur(2));mask=mask.point(lambda p:int(p*.30));glow=Image.new('RGBA',im.size,(45,183,181,0));glow.putalpha(mask);glow.alpha_composite(im);im=glow
  if not im.getbbox():raise RuntimeError('Empty frame')
  atlas.paste(im,((i%COLS)*size,(i//COLS)*size))
 out.parent.mkdir(parents=True,exist_ok=True);atlas.save(out,'WEBP',quality=87,method=4,alpha_quality=100,exact=True)
 # Match the original game's approximate projected body height while preserving proportions.
 alive=np.concatenate([q[0].reshape(-1,3) for q in poses[:20]]);unit=worldheight/max(1e-5,np.ptp(alive@UP));worldpx=unit/scale
 return {'file':out.name,'size':size,'cols':COLS,'rows':ROWS,'ax':round(float(ax),3),'ay':round(float(ay),3),'scale':round(float(worldpx),5),'kind':m.kind}

HERO={'danil':'kaz/hero','subedey':'mon/hero','bogdan':'bog/hero','krovchinski':'nov/hero','admiral_eston':'boss/admiral','undead_pirate':'special/undead_pirate'}
def main():
 source=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True);meta={}
 with zipfile.ZipFile(source) as z:
  recs=json.loads(z.read('manifest.json'))
  base=next(r for r in recs if r['id']=='special/fog_undead');risen=next(r for r in recs if r['id']=='special/risen')
  for i,(name,weapon,hat,skin) in enumerate([('Утопленник','sabre','hood','9ebfb5'),('Костяной стрелок','bow','none','b1c8ce'),('Мертвый боцман','club','pirate','b7a6d0'),('Туманный вестник','staff','hood','87d4d7')]):
   recs.append({**base,'id':'special/haunted_'+str(i),'name':name,'weapon':weapon,'hat':hat,'skin_tint':skin,'undead_role':i})
  recs.append({**risen,'id':'special/risen_archer','name':'Восставший стрелок','weapon':'bow','hat':'none'})
  for name,id in HERO.items():
   m=GLBModel(z.read('heroes/'+name+'_v2.glb'));m.glow=name in ('admiral_eston','undead_pirate');m.kind='human';dest=out/(id.replace('/','_')+'.webp');meta[id]=bake(m,m.maps,128,43 if name!='admiral_eston' else 48,dest);print(id,dest.stat().st_size,flush=True)
  for r in recs:
   id=r['id'];m,mat=procedural(z,r);size=128 if id.startswith(('boss/','vehicle/')) else 96;kind=r['kind'];height=50 if kind=='mounted' else 22 if kind=='animal' else 40
   if id=='animal/bear':height=34
   if kind=='vehicle':height=80 if id!='vehicle/wagon' else 38
   if id.startswith('boss/'):height=45
   dest=out/(id.replace('/','_')+'.webp');meta[id]=bake(m,mat,size,height,dest);meta[id]['name']=r['name'];print(id,dest.stat().st_size,flush=True)
  # Metadata includes aliases and anchor geometry. Animation timing is controlled by drawU/drawA.
  (out.parent/'sprites.json').write_text(json.dumps(meta,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
  print('TOTAL',len(meta),sum(x.stat().st_size for x in out.glob('*.webp')),flush=True)
if __name__=='__main__':main()
