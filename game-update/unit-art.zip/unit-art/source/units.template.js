/* KW_UNIT_ART_V2 — pre-baked orthographic animation atlases.
   Draw-only extension. No gameplay, RNG, network protocol or simulation mutations.
   4 idle + 8 locomotion + 8 attack/work + 4 death frames per sprite. */
(()=>{'use strict';
if(typeof drawU!=='function'||typeof drawA!=='function'||typeof drawFX!=='function')return;
const meta=__META__;
const base=new globalThis.URL('unit-art/sprites/',document.baseURI);
const names=new Map(Object.entries(meta).filter(([,m])=>m.name).map(([id,m])=>[m.name,id]));
const races=new Set(['kaz','nov','mon','bog']);
const cache=new Map(),pending=[],guestVisual=new WeakMap();
const MAX_DECODED=56*1024*1024,MAX_INFLIGHT=3;
let active=0,decoded=0,serial=0,errors=0,lastTrim=-Infinity;
const clamp=(v,l,h)=>Math.max(l,Math.min(h,v)),mod=(v,n)=>((v%n)+n)%n;
const clock=()=>performance.now();
function trim(){
 if(decoded<=MAX_DECODED)return;
 const now=clock();lastTrim=now;const candidates=[...cache.values()].filter(e=>e.state==='ready'&&now-e.used>10000).sort((a,b)=>a.used-b.used);
 for(const e of candidates){if(decoded<=MAX_DECODED)break;decoded-=e.bytes;cache.delete(e.id);e.img=null;e.state='evicted';}
}
function pump(){
 while(active<MAX_INFLIGHT&&pending.length){
  const e=pending.shift();if(e.state!=='queued')continue;
  active++;e.state='loading';const im=new Image();e.img=im;
  const settle=ok=>{active--;im.onload=im.onerror=null;if(ok&&im.naturalWidth===e.m.size*e.m.cols&&im.naturalHeight===e.m.size*e.m.rows){e.state='ready';e.bytes=im.naturalWidth*im.naturalHeight*4;decoded+=e.bytes;}else{e.state='failed';e.img=null;errors++;}trim();pump()};
  im.onload=()=>settle(true);im.onerror=()=>settle(false);im.decoding='async';im.src=new globalThis.URL(e.m.file,base).href;
 }
}
function request(id){
 if(!id||!Object.prototype.hasOwnProperty.call(meta,id))return null;
 let e=cache.get(id);if(!e){e={id,m:meta[id],state:'queued',used:clock(),order:serial++,img:null,bytes:0};cache.set(id,e);pending.push(e);pump()}
 e.used=clock();if(decoded>MAX_DECODED&&e.used-lastTrim>1000)trim();return e;
}
function keyFor(e){
 if(!e)return null;
 if(e.ship)return 'vehicle/'+(e.ship==='boss'?'flagship':'escort');
 if(e.kind==='cache')return 'vehicle/wagon';
 if(e.boardingHuman)return 'boss/admiral';
 if(Number.isInteger(e.hauntedRole)&&e.hauntedRole>=0&&e.hauntedRole<=3)return 'special/haunted_'+e.hauntedRole;
 if(e.undeadBoarder)return e.seaUndead?((e.rng||0)>60?'special/risen_archer':'special/risen'):'special/undead_pirate';
 if(e.seaUndead)return (e.rng||0)>60?'special/risen_archer':'special/risen';
 if(e.arab)return 'special/arab';if(e.roommate)return 'special/roommate';
 if(e.civilian)return 'special/civilian';if(e.localGuard)return 'special/militia';if(e.trialGuard)return 'special/passage_guard';
 if(e.race==='cr'||e.spec?.a){const a=e.spec?.a||['boar','wolf','bear','deer','hare','fox'][e.ci];return meta['animal/'+a]?'animal/'+a:null}
 const n=e.nm||'',d=e.spec?.nm||'';
 if(n.startsWith('Из тумана'))return 'special/fog_undead';
 if(n.startsWith('Восставший'))return (e.rng||0)>60?'special/risen_archer':'special/risen';
 if(n.startsWith('Адмирал Эстон'))return 'boss/admiral';if(n==='Мертвец-пират')return 'special/undead_pirate';
 if(e.relic){const id=names.get(n);if(id?.startsWith('boss/'))return id;}
 if(races.has(e.race)){
  const r=e.race;
  if(e.militia)return r+'/militia';if(e.spy||e.i===8)return r+'/spy';
  if(e.i===9||((typeof RC!=='undefined')&&e.spec?.nm===RC[r]?.H?.nm))return r+'/hero';
  if(e.siegeWeapon)return r+'/siege';if(e.legendary)return r+'/legend';
  const named=names.get(n);if(named)return named;
  if(e.wk||e.i===-1)return r+'/worker';
  if(Number.isInteger(e.i)&&e.i>=0&&meta[r+'/unit_'+(e.i+1)])return r+'/unit_'+(e.i+1);
  const bySpec=names.get(d);if(bySpec)return bySpec;
 }else{const named=names.get(n)||names.get(d);if(named)return named}
 return null;
}
function visualPose(e,P){
 let ph=Number(P.ph)||0,mv=!!P.mv,sw=Number.isFinite(P.sw)?P.sw:-1;
 // Guests interpolate rendered positions between host snapshots. Animate from
 // those positions instead of starting/stopping legs on every received packet.
 if(e?.k==='u'&&Number.isFinite(e.x)&&Number.isFinite(e.y)&&window.kubanOnlineAlpha?.role==='guest'&&window.kubanOnlineAlpha?.currentMatch){
  const now=clock();let a=guestVisual.get(e);if(!a){a={x:e.x,y:e.y,ph,move:now-500,sw,swAt:now};guestVisual.set(e,a)}
  const dist=Math.hypot(e.x-a.x,e.y-a.y);a.x=e.x;a.y=e.y;
  if(dist>.015&&dist<120){a.ph+=dist*.16;a.move=now}else if(dist>=120){a.ph=ph;a.move=now-500;}
  if(sw!==a.sw){a.sw=sw;a.swAt=now;}
  if(sw>=0)sw=clamp(sw+(now-a.swAt)/400,0,1);
  mv=mv||now-a.move<120;ph=a.ph;
 }
 return {ph,mv,sw};
}
function frameFor(e,P={}){
 if(Number.isFinite(P.death))return 20+Math.round(clamp(P.death,0,1)*3);
 const a=visualPose(e,P),low=typeof ST!=='undefined'&&Number(ST.q)===0;
 if(a.sw>=0){let f=Math.round(clamp(a.sw,0,1)*7);if(low)f=Math.min(7,Math.round(f/2)*2);return 12+f}
 if(a.mv){let f=mod(Math.floor(a.ph*8/(2*Math.PI)),8);if(low)f=f&~1;return 4+f}
 const tm=Number(P.t)||0,offset=(Number(P.id??e?.id)||0)%13*.073;
 let f=mod(Math.floor((tm+offset)*2.5),4);if(low)f=f&~1;return f;
}
function paint(c,e,id,x,y,k,P={}){
 if(!Number.isFinite(k)||k<=0||!Number.isFinite(x)||!Number.isFinite(y))return false;
 const a=request(id);if(!a||a.state!=='ready')return false;
 const m=a.m,f=frameFor(e,P),s=m.size,scale=m.scale,fx=(P.fx||1)<0?-1:1;
 c.save();c.translate(x,y);if(P.rot&&!Number.isFinite(P.death))c.rotate(P.rot*fx);
 c.scale(k*fx*(P.width||1),k*(P.height||1));
 if(Number.isFinite(P.al))c.globalAlpha*=clamp(P.al,0,1);
 c.imageSmoothingEnabled=true;c.imageSmoothingQuality=typeof ST!=='undefined'&&ST.q===0?'low':'medium';
 c.drawImage(a.img,(f%m.cols)*s,Math.floor(f/m.cols)*s,s,s,-m.ax*scale,-m.ay*scale,s*scale,s*scale);
 c.restore();return true;
}
const oldU=drawU,oldA=drawA,oldFX=drawFX;
drawU=function(c,e,x,y,k,P){if(paint(c,e,keyFor(e),x,y,k,P||{}))return;return oldU.apply(this,arguments)};
drawA=function(c,e,x,y,k,P){if(paint(c,e,keyFor(e),x,y,k,P||{}))return;return oldA.apply(this,arguments)};
drawFX=function(f){
 if(f?.ty==='c'&&f.e&&!f.e.ship&&Number.isFinite(f.a)&&f.a>0){
  const e=f.e,k=e.r/(e.race==='cr'?(e.ci===2?20:11):9.5),age=Math.max(0,f.a-f.l);
  if(paint(g,e,keyFor(e),e.x,e.y+e.r*.75,k,{death:clamp(age/.42,0,1),fx:e.fx,al:clamp(f.l/f.a*1.6,0,1),id:e.id}))return;
 }
 return oldFX.apply(this,arguments);
};
if(typeof paintShip==='function'){
 const oldShip=paintShip;
 paintShip=function(c,x,y,k,boss,shield){
  const id=boss?'vehicle/flagship':'vehicle/escort',a=request(id);if(a?.state!=='ready')return oldShip.apply(this,arguments);
  const tm=typeof t==='number'?t:0,phase=typeof naval!=='undefined'?naval?.phase||1:1,glow=shield?'#8bdcfb':phase===3?'#e3a3ff':'#8ce7d4';
  c.save();c.translate(x,y);c.scale(k,k);
  const q=typeof ST==='undefined'||ST.q>0;
  if(q){c.save();c.globalAlpha*=.25;c.strokeStyle=glow;c.lineWidth=2;for(let j=0;j<3;j++){c.beginPath();c.ellipse(0,12+j*5,78+j*8,24+j*6,0,0,Math.PI*2);c.stroke()}c.restore()}
  paint(c,{id:boss?1:2},id,0,19+Math.sin(tm*1.9)*2.4,1,{t:tm,fx:1,width:1.55,height:.9});
  if(shield){c.save();c.strokeStyle='#7cd8f5';c.lineWidth=4;c.globalAlpha*=.85;c.beginPath();c.ellipse(0,0,99,47,0,0,Math.PI*2);c.stroke();c.restore()}
  c.restore();
 };
}
// Queue only the chosen faction's common units before battle; the rest load lazily.
function warmRace(r){if(!races.has(r))return;request(r+'/hero');request(r+'/worker');for(let i=1;i<=4;i++)if(meta[r+'/unit_'+i])request(r+'/unit_'+i)}
if(typeof start==='function'){const oldStart=start;start=function(p,e,...args){warmRace(p);warmRace(e);return oldStart.call(this,p,e,...args)}}
window.KWUnitArt=Object.freeze({
 version:2,keyFor,frameFor,
 paintCache(c,e){return paint(c,e,'vehicle/wagon',0,19,.9,{t:typeof t==='number'?t:0,fx:1,al:e.sold?.cache?0.78:1})},
 preload(id){request(id)},
 stats(){return {sprites:Object.keys(meta).length,loaded:[...cache.values()].filter(a=>a.state==='ready').length,queued:pending.length,inflight:active,estimatedDecodedBytes:decoded,errors,frameCount:24}},
});
})();
