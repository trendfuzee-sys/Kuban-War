/* KW_UNIT_ART_V2 — pre-baked orthographic animation atlases.
   Draw-only extension. No gameplay, RNG, network protocol or simulation mutations.
   4 idle + 8 locomotion + 8 attack/work + 4 death frames per sprite. */
(()=>{'use strict';
if(typeof drawU!=='function'||typeof drawA!=='function'||typeof drawFX!=='function')return;
const meta={"kaz/hero":{"file":"kaz_hero.webp","size":128,"cols":6,"rows":4,"ax":88.03,"ay":98.731,"scale":0.4365,"kind":"human"},"mon/hero":{"file":"mon_hero.webp","size":128,"cols":6,"rows":4,"ax":89.112,"ay":100.896,"scale":0.42893,"kind":"human"},"bog/hero":{"file":"bog_hero.webp","size":128,"cols":6,"rows":4,"ax":87.671,"ay":103.45,"scale":0.4187,"kind":"human"},"nov/hero":{"file":"nov_hero.webp","size":128,"cols":6,"rows":4,"ax":90.405,"ay":108.375,"scale":0.40087,"kind":"human"},"boss/admiral":{"file":"boss_admiral.webp","size":128,"cols":6,"rows":4,"ax":89.281,"ay":100.29,"scale":0.48114,"kind":"human"},"special/undead_pirate":{"file":"special_undead_pirate.webp","size":128,"cols":6,"rows":4,"ax":89.281,"ay":100.29,"scale":0.43102,"kind":"human"},"kaz/worker":{"file":"kaz_worker.webp","size":96,"cols":6,"rows":4,"ax":63.933,"ay":74.392,"scale":0.53406,"kind":"human","name":"Хлебороб"},"kaz/unit_1":{"file":"kaz_unit_1.webp","size":96,"cols":6,"rows":4,"ax":64.412,"ay":73.987,"scale":0.53803,"kind":"human","name":"Шашечник"},"kaz/unit_2":{"file":"kaz_unit_2.webp","size":96,"cols":6,"rows":4,"ax":66.777,"ay":75.568,"scale":0.65228,"kind":"mounted","name":"Джигит"},"kaz/unit_3":{"file":"kaz_unit_3.webp","size":96,"cols":6,"rows":4,"ax":66.984,"ay":78.814,"scale":0.51068,"kind":"human","name":"Пластун"},"nov/worker":{"file":"nov_worker.webp","size":96,"cols":6,"rows":4,"ax":63.788,"ay":73.862,"scale":0.53659,"kind":"human","name":"Работяга"},"nov/unit_1":{"file":"nov_unit_1.webp","size":96,"cols":6,"rows":4,"ax":63.91,"ay":74.394,"scale":0.53248,"kind":"human","name":"Гопник"},"nov/unit_2":{"file":"nov_unit_2.webp","size":96,"cols":6,"rows":4,"ax":62.983,"ay":76.462,"scale":0.53447,"kind":"human","name":"Бугай с розочкой"},"mon/worker":{"file":"mon_worker.webp","size":96,"cols":6,"rows":4,"ax":65.068,"ay":76.208,"scale":0.53057,"kind":"human","name":"Пастух"},"mon/unit_1":{"file":"mon_unit_1.webp","size":96,"cols":6,"rows":4,"ax":67.859,"ay":79.041,"scale":0.62878,"kind":"mounted","name":"Конный лучник"},"mon/unit_2":{"file":"mon_unit_2.webp","size":96,"cols":6,"rows":4,"ax":63.608,"ay":74.594,"scale":0.53317,"kind":"human","name":"Багатур"},"mon/unit_3":{"file":"mon_unit_3.webp","size":96,"cols":6,"rows":4,"ax":59.927,"ay":73.431,"scale":0.55755,"kind":"human","name":"Кешиктен"},"mon/unit_4":{"file":"mon_unit_4.webp","size":96,"cols":6,"rows":4,"ax":66.646,"ay":76.731,"scale":0.64635,"kind":"mounted","name":"Конный копейщик"},"bog/worker":{"file":"bog_worker.webp","size":96,"cols":6,"rows":4,"ax":66.04,"ay":78.631,"scale":0.51893,"kind":"human","name":"Студент"},"bog/unit_1":{"file":"bog_unit_1.webp","size":96,"cols":6,"rows":4,"ax":66.04,"ay":78.631,"scale":0.51893,"kind":"human","name":"Ботан"},"bog/unit_2":{"file":"bog_unit_2.webp","size":96,"cols":6,"rows":4,"ax":64.624,"ay":77.882,"scale":0.52777,"kind":"human","name":"Заочник"},"bog/unit_3":{"file":"bog_unit_3.webp","size":96,"cols":6,"rows":4,"ax":65.068,"ay":76.208,"scale":0.53057,"kind":"human","name":"Старшекурсник"},"kaz/spy":{"file":"kaz_spy.webp","size":96,"cols":6,"rows":4,"ax":64.624,"ay":77.882,"scale":0.52777,"kind":"human","name":"Лазутчик"},"nov/spy":{"file":"nov_spy.webp","size":96,"cols":6,"rows":4,"ax":64.624,"ay":77.882,"scale":0.52777,"kind":"human","name":"Осведомитель"},"mon/spy":{"file":"mon_spy.webp","size":96,"cols":6,"rows":4,"ax":64.624,"ay":77.882,"scale":0.52777,"kind":"human","name":"Степной разведчик"},"bog/spy":{"file":"bog_spy.webp","size":96,"cols":6,"rows":4,"ax":64.624,"ay":77.882,"scale":0.52777,"kind":"human","name":"Шпион общаги"},"kaz/siege":{"file":"kaz_siege.webp","size":96,"cols":6,"rows":4,"ax":66.126,"ay":76.208,"scale":0.53057,"kind":"siege","name":"Полевая пушка"},"kaz/legend":{"file":"kaz_legend.webp","size":96,"cols":6,"rows":4,"ax":64.635,"ay":74.644,"scale":0.5348,"kind":"human","name":"Старый атаман"},"nov/siege":{"file":"nov_siege.webp","size":96,"cols":6,"rows":4,"ax":66.126,"ay":76.208,"scale":0.53057,"kind":"siege","name":"Самодельная мортира"},"nov/legend":{"file":"nov_legend.webp","size":96,"cols":6,"rows":4,"ax":64.635,"ay":74.644,"scale":0.5348,"kind":"human","name":"Бессмертный беглец"},"mon/siege":{"file":"mon_siege.webp","size":96,"cols":6,"rows":4,"ax":66.126,"ay":76.208,"scale":0.53057,"kind":"siege","name":"Осадный таран"},"mon/legend":{"file":"mon_legend.webp","size":96,"cols":6,"rows":4,"ax":59.927,"ay":73.431,"scale":0.55755,"kind":"human","name":"Ханский телохранитель"},"bog/siege":{"file":"bog_siege.webp","size":96,"cols":6,"rows":4,"ax":66.126,"ay":76.208,"scale":0.53057,"kind":"siege","name":"Самодельная артиллерия"},"bog/legend":{"file":"bog_legend.webp","size":96,"cols":6,"rows":4,"ax":64.635,"ay":74.644,"scale":0.5348,"kind":"human","name":"Боевой аспирант"},"boss/relic_0":{"file":"boss_relic_0.webp","size":128,"cols":6,"rows":4,"ax":84.154,"ay":99.46,"scale":0.44037,"kind":"human","name":"Бешеный атаман"},"boss/relic_1":{"file":"boss_relic_1.webp","size":128,"cols":6,"rows":4,"ax":77.263,"ay":96.86,"scale":0.48605,"kind":"human","name":"Смотритель катакомб"},"boss/relic_2":{"file":"boss_relic_2.webp","size":128,"cols":6,"rows":4,"ax":72.619,"ay":97.669,"scale":0.50886,"kind":"human","name":"Хмельной громила"},"boss/relic_3":{"file":"boss_relic_3.webp","size":128,"cols":6,"rows":4,"ax":77.625,"ay":96.847,"scale":0.48049,"kind":"human","name":"Начальник изолятора"},"boss/relic_4":{"file":"boss_relic_4.webp","size":128,"cols":6,"rows":4,"ax":72.81,"ay":95.468,"scale":0.50888,"kind":"golem","name":"Степной идол"},"boss/relic_5":{"file":"boss_relic_5.webp","size":128,"cols":6,"rows":4,"ax":84.524,"ay":102.734,"scale":0.43206,"kind":"human","name":"Болотный старец"},"boss/relic_6":{"file":"boss_relic_6.webp","size":128,"cols":6,"rows":4,"ax":85.521,"ay":102.734,"scale":0.43206,"kind":"human","name":"Безумный лаборант"},"boss/relic_7":{"file":"boss_relic_7.webp","size":128,"cols":6,"rows":4,"ax":73.21,"ay":97.122,"scale":0.50719,"kind":"golem","name":"Мусорный голем"},"boss/relic_8":{"file":"boss_relic_8.webp","size":128,"cols":6,"rows":4,"ax":84.305,"ay":99.484,"scale":0.44068,"kind":"human","name":"Проклятый капитан"},"animal/boar":{"file":"animal_boar.webp","size":96,"cols":6,"rows":4,"ax":51.931,"ay":62.761,"scale":0.41941,"kind":"animal","name":"Кабан"},"animal/wolf":{"file":"animal_wolf.webp","size":96,"cols":6,"rows":4,"ax":57.569,"ay":66.831,"scale":0.37356,"kind":"animal","name":"Волк"},"animal/bear":{"file":"animal_bear.webp","size":96,"cols":6,"rows":4,"ax":56.139,"ay":66.565,"scale":0.59886,"kind":"animal","name":"Медведь"},"animal/deer":{"file":"animal_deer.webp","size":96,"cols":6,"rows":4,"ax":58.107,"ay":71.353,"scale":0.30501,"kind":"animal","name":"Олень"},"animal/hare":{"file":"animal_hare.webp","size":96,"cols":6,"rows":4,"ax":51.142,"ay":71.675,"scale":0.30081,"kind":"animal","name":"Заяц"},"animal/fox":{"file":"animal_fox.webp","size":96,"cols":6,"rows":4,"ax":56.029,"ay":65.239,"scale":0.38494,"kind":"animal","name":"Лиса"},"special/arab":{"file":"special_arab.webp","size":96,"cols":6,"rows":4,"ax":64.537,"ay":74.808,"scale":0.53057,"kind":"human","name":"Араб"},"special/roommate":{"file":"special_roommate.webp","size":96,"cols":6,"rows":4,"ax":64.624,"ay":77.882,"scale":0.52777,"kind":"human","name":"Сожитель"},"special/civilian":{"file":"special_civilian.webp","size":96,"cols":6,"rows":4,"ax":64.624,"ay":77.349,"scale":0.52777,"kind":"human","name":"Местный житель"},"special/militia":{"file":"special_militia.webp","size":96,"cols":6,"rows":4,"ax":64.246,"ay":73.581,"scale":0.54005,"kind":"human","name":"Местное ополчение"},"special/guard":{"file":"special_guard.webp","size":96,"cols":6,"rows":4,"ax":64.246,"ay":73.581,"scale":0.54005,"kind":"human","name":"Страж"},"special/passage_guard":{"file":"special_passage_guard.webp","size":96,"cols":6,"rows":4,"ax":64.246,"ay":73.581,"scale":0.54005,"kind":"human","name":"Страж прохода"},"special/barrier_guard":{"file":"special_barrier_guard.webp","size":96,"cols":6,"rows":4,"ax":64.246,"ay":73.581,"scale":0.54005,"kind":"human","name":"Вражеский заслон"},"special/risen":{"file":"special_risen.webp","size":96,"cols":6,"rows":4,"ax":64.246,"ay":73.581,"scale":0.54005,"kind":"undead","name":"Восставший"},"special/fog_undead":{"file":"special_fog_undead.webp","size":96,"cols":6,"rows":4,"ax":64.246,"ay":73.581,"scale":0.54005,"kind":"undead","name":"Из тумана"},"kaz/militia":{"file":"kaz_militia.webp","size":96,"cols":6,"rows":4,"ax":64.052,"ay":74.911,"scale":0.53009,"kind":"human","name":"Хлебороб (ополчение)"},"nov/militia":{"file":"nov_militia.webp","size":96,"cols":6,"rows":4,"ax":63.91,"ay":74.394,"scale":0.53248,"kind":"human","name":"Работяга (ополчение)"},"mon/militia":{"file":"mon_militia.webp","size":96,"cols":6,"rows":4,"ax":64.281,"ay":74.849,"scale":0.53038,"kind":"human","name":"Пастух (ополчение)"},"bog/militia":{"file":"bog_militia.webp","size":96,"cols":6,"rows":4,"ax":63.882,"ay":74.429,"scale":0.53232,"kind":"human","name":"Студент (ополчение)"},"vehicle/flagship":{"file":"vehicle_flagship.webp","size":128,"cols":6,"rows":4,"ax":79.94,"ay":99.743,"scale":0.80282,"kind":"vehicle","name":"Флагман Адмирала Эстона"},"vehicle/escort":{"file":"vehicle_escort.webp","size":128,"cols":6,"rows":4,"ax":86.397,"ay":102.997,"scale":0.76207,"kind":"vehicle","name":"Корабль охраны"},"vehicle/wagon":{"file":"vehicle_wagon.webp","size":128,"cols":6,"rows":4,"ax":66.015,"ay":90.96,"scale":0.51053,"kind":"vehicle","name":"Обоз"},"special/haunted_0":{"file":"special_haunted_0.webp","size":96,"cols":6,"rows":4,"ax":64.246,"ay":73.581,"scale":0.54005,"kind":"undead","name":"Утопленник"},"special/haunted_1":{"file":"special_haunted_1.webp","size":96,"cols":6,"rows":4,"ax":66.04,"ay":77.863,"scale":0.51893,"kind":"undead","name":"Костяной стрелок"},"special/haunted_2":{"file":"special_haunted_2.webp","size":96,"cols":6,"rows":4,"ax":63.598,"ay":75.117,"scale":0.5341,"kind":"undead","name":"Мертвый боцман"},"special/haunted_3":{"file":"special_haunted_3.webp","size":96,"cols":6,"rows":4,"ax":65.068,"ay":76.208,"scale":0.53057,"kind":"undead","name":"Туманный вестник"},"special/risen_archer":{"file":"special_risen_archer.webp","size":96,"cols":6,"rows":4,"ax":66.04,"ay":77.863,"scale":0.51893,"kind":"undead","name":"Восставший стрелок"}};
const base=new globalThis.URL('unit-art/sprites/',document.baseURI);
const names=new Map(Object.entries(meta).filter(([,m])=>m.name).map(([id,m])=>[m.name,id]));
const races=new Set(['kaz','nov','mon','bog']);
const cache=new Map(),pending=[],guestVisual=new WeakMap();
const MAX_DECODED=56*1024*1024,MAX_INFLIGHT=3;
let active=0,decoded=0,serial=0,errors=0,lastTrim=-Infinity;
const clamp=(v,l,h)=>Math.max(l,Math.min(h,v)),mod=(v,n)=>((v%n)+n)%n;
const clock=()=>performance.now();
function trim(){
 if(decoded<=MAX_DECODED)return;
 const now=clock();lastTrim=now;const candidates=[...cache.values()].filter(e=>e.state==='ready'&&now-e.used>10000).sort((a,b)=>a.used-b.used);
 for(const e of candidates){if(decoded<=MAX_DECODED)break;decoded-=e.bytes;cache.delete(e.id);e.img=null;e.state='evicted';}
}
function pump(){
 while(active<MAX_INFLIGHT&&pending.length){
  const e=pending.shift();if(e.state!=='queued')continue;
  active++;e.state='loading';const im=new Image();e.img=im;
  const settle=ok=>{active--;im.onload=im.onerror=null;if(ok&&im.naturalWidth===e.m.size*e.m.cols&&im.naturalHeight===e.m.size*e.m.rows){e.state='ready';e.bytes=im.naturalWidth*im.naturalHeight*4;decoded+=e.bytes;}else{e.state='failed';e.img=null;errors++;}trim();pump()};
  im.onload=()=>settle(true);im.onerror=()=>settle(false);im.decoding='async';im.src=new globalThis.URL(e.m.file,base).href;
 }
}
function request(id){
 if(!id||!Object.prototype.hasOwnProperty.call(meta,id))return null;
 let e=cache.get(id);if(!e){e={id,m:meta[id],state:'queued',used:clock(),order:serial++,img:null,bytes:0};cache.set(id,e);pending.push(e);pump()}
 e.used=clock();if(decoded>MAX_DECODED&&e.used-lastTrim>1000)trim();return e;
}
function keyFor(e){
 if(!e)return null;
 if(e.ship)return 'vehicle/'+(e.ship==='boss'?'flagship':'escort');
 if(e.kind==='cache')return 'vehicle/wagon';
 if(e.boardingHuman)return 'boss/admiral';
 if(Number.isInteger(e.hauntedRole)&&e.hauntedRole>=0&&e.hauntedRole<=3)return 'special/haunted_'+e.hauntedRole;
 if(e.undeadBoarder)return e.seaUndead?((e.rng||0)>60?'special/risen_archer':'special/risen'):'special/undead_pirate';
 if(e.seaUndead)return (e.rng||0)>60?'special/risen_archer':'special/risen';
 if(e.arab)return 'special/arab';if(e.roommate)return 'special/roommate';
 if(e.civilian)return 'special/civilian';if(e.localGuard)return 'special/militia';if(e.trialGuard)return 'special/passage_guard';
 if(e.race==='cr'||e.spec?.a){const a=e.spec?.a||['boar','wolf','bear','deer','hare','fox'][e.ci];return meta['animal/'+a]?'animal/'+a:null}
 const n=e.nm||'',d=e.spec?.nm||'';
 if(n.startsWith('Из тумана'))return 'special/fog_undead';
 if(n.startsWith('Восставший'))return (e.rng||0)>60?'special/risen_archer':'special/risen';
 if(n.startsWith('Адмирал Эстон'))return 'boss/admiral';if(n==='Мертвец-пират')return 'special/undead_pirate';
 if(e.relic){const id=names.get(n);if(id?.startsWith('boss/'))return id;}
 if(races.has(e.race)){
  const r=e.race;
  if(e.militia)return r+'/militia';if(e.spy||e.i===8)return r+'/spy';
  if(e.i===9||((typeof RC!=='undefined')&&e.spec?.nm===RC[r]?.H?.nm))return r+'/hero';
  if(e.siegeWeapon)return r+'/siege';if(e.legendary)return r+'/legend';
  const named=names.get(n);if(named)return named;
  if(e.wk||e.i===-1)return r+'/worker';
  if(Number.isInteger(e.i)&&e.i>=0&&meta[r+'/unit_'+(e.i+1)])return r+'/unit_'+(e.i+1);
  const bySpec=names.get(d);if(bySpec)return bySpec;
 }else{const named=names.get(n)||names.get(d);if(named)return named}
 return null;
}
function visualPose(e,P){
 let ph=Number(P.ph)||0,mv=!!P.mv,sw=Number.isFinite(P.sw)?P.sw:-1;
 // Guests interpolate rendered positions between host snapshots. Animate from
 // those positions instead of starting/stopping legs on every received packet.
 if(e?.k==='u'&&Number.isFinite(e.x)&&Number.isFinite(e.y)&&window.kubanOnlineAlpha?.role==='guest'&&window.kubanOnlineAlpha?.currentMatch){
  const now=clock();let a=guestVisual.get(e);if(!a){a={x:e.x,y:e.y,ph,move:now-500,sw,swAt:now};guestVisual.set(e,a)}
  const dist=Math.hypot(e.x-a.x,e.y-a.y);a.x=e.x;a.y=e.y;
  if(dist>.015&&dist<120){a.ph+=dist*.16;a.move=now}else if(dist>=120){a.ph=ph;a.move=now-500;}
  if(sw!==a.sw){a.sw=sw;a.swAt=now;}
  if(sw>=0)sw=clamp(sw+(now-a.swAt)/400,0,1);
  mv=mv||now-a.move<120;ph=a.ph;
 }
 return {ph,mv,sw};
}
function frameFor(e,P={}){
 if(Number.isFinite(P.death))return 20+Math.round(clamp(P.death,0,1)*3);
 const a=visualPose(e,P),low=typeof ST!=='undefined'&&Number(ST.q)===0;
 if(a.sw>=0){let f=Math.round(clamp(a.sw,0,1)*7);if(low)f=Math.min(7,Math.round(f/2)*2);return 12+f}
 if(a.mv){let f=mod(Math.floor(a.ph*8/(2*Math.PI)),8);if(low)f=f&~1;return 4+f}
 const tm=Number(P.t)||0,offset=(Number(P.id??e?.id)||0)%13*.073;
 let f=mod(Math.floor((tm+offset)*2.5),4);if(low)f=f&~1;return f;
}
function paint(c,e,id,x,y,k,P={}){
 if(!Number.isFinite(k)||k<=0||!Number.isFinite(x)||!Number.isFinite(y))return false;
 const a=request(id);if(!a||a.state!=='ready')return false;
 const m=a.m,f=frameFor(e,P),s=m.size,scale=m.scale,fx=(P.fx||1)<0?-1:1;
 c.save();c.translate(x,y);if(P.rot&&!Number.isFinite(P.death))c.rotate(P.rot*fx);
 c.scale(k*fx*(P.width||1),k*(P.height||1));
 if(Number.isFinite(P.al))c.globalAlpha*=clamp(P.al,0,1);
 c.imageSmoothingEnabled=true;c.imageSmoothingQuality=typeof ST!=='undefined'&&ST.q===0?'low':'medium';
 c.drawImage(a.img,(f%m.cols)*s,Math.floor(f/m.cols)*s,s,s,-m.ax*scale,-m.ay*scale,s*scale,s*scale);
 c.restore();return true;
}
const oldU=drawU,oldA=drawA,oldFX=drawFX;
drawU=function(c,e,x,y,k,P){if(paint(c,e,keyFor(e),x,y,k,P||{}))return;return oldU.apply(this,arguments)};
drawA=function(c,e,x,y,k,P){if(paint(c,e,keyFor(e),x,y,k,P||{}))return;return oldA.apply(this,arguments)};
drawFX=function(f){
 if(f?.ty==='c'&&f.e&&!f.e.ship&&Number.isFinite(f.a)&&f.a>0){
  const e=f.e,k=e.r/(e.race==='cr'?(e.ci===2?20:11):9.5),age=Math.max(0,f.a-f.l);
  if(paint(g,e,keyFor(e),e.x,e.y+e.r*.75,k,{death:clamp(age/.42,0,1),fx:e.fx,al:clamp(f.l/f.a*1.6,0,1),id:e.id}))return;
 }
 return oldFX.apply(this,arguments);
};
if(typeof paintShip==='function'){
 const oldShip=paintShip;
 paintShip=function(c,x,y,k,boss,shield){
  const id=boss?'vehicle/flagship':'vehicle/escort',a=request(id);if(a?.state!=='ready')return oldShip.apply(this,arguments);
  const tm=typeof t==='number'?t:0,phase=typeof naval!=='undefined'?naval?.phase||1:1,glow=shield?'#8bdcfb':phase===3?'#e3a3ff':'#8ce7d4';
  c.save();c.translate(x,y);c.scale(k,k);
  const q=typeof ST==='undefined'||ST.q>0;
  if(q){c.save();c.globalAlpha*=.25;c.strokeStyle=glow;c.lineWidth=2;for(let j=0;j<3;j++){c.beginPath();c.ellipse(0,12+j*5,78+j*8,24+j*6,0,0,Math.PI*2);c.stroke()}c.restore()}
  paint(c,{id:boss?1:2},id,0,19+Math.sin(tm*1.9)*2.4,1,{t:tm,fx:1,width:1.55,height:.9});
  if(shield){c.save();c.strokeStyle='#7cd8f5';c.lineWidth=4;c.globalAlpha*=.85;c.beginPath();c.ellipse(0,0,99,47,0,0,Math.PI*2);c.stroke();c.restore()}
  c.restore();
 };
}
// Queue only the chosen faction's common units before battle; the rest load lazily.
function warmRace(r){if(!races.has(r))return;request(r+'/hero');request(r+'/worker');for(let i=1;i<=4;i++)if(meta[r+'/unit_'+i])request(r+'/unit_'+i)}
if(typeof start==='function'){const oldStart=start;start=function(p,e,...args){warmRace(p);warmRace(e);return oldStart.call(this,p,e,...args)}}
window.KWUnitArt=Object.freeze({
 version:2,keyFor,frameFor,
 paintCache(c,e){return paint(c,e,'vehicle/wagon',0,19,.9,{t:typeof t==='number'?t:0,fx:1,al:e.sold?.cache?0.78:1})},
 preload(id){request(id)},
 stats(){return {sprites:Object.keys(meta).length,loaded:[...cache.values()].filter(a=>a.state==='ready').length,queued:pending.length,inflight:active,estimatedDecodedBytes:decoded,errors,frameCount:24}},
});
})();
